# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sub:FTP/;
$ref_files{$key} = "$dir".q|decal_lab_week4.html|; 
$noresave{$key} = "$nosave";

1;

