/* Small program to allocate lots of memory first, then try
   to use it.   Sleeps until interrupted by SIGHUP, then reads all
   of the memory it scribbled on. */

/* Each block is 4 MB in size */
#define BLOCKS 6

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>

int received_hup = 0;

void onhup(int signum);

int main() {
	size_t memory = 1024*1024*sizeof(int);
	void * ptr;
	void * blocks[BLOCKS];
	long i, j;
	int blocks_allocated = 0;
	struct timeval resume_time, finish_time;

	/* Acquire lots of memory first */
	for (i = 0; i < BLOCKS; i++) {
		if ((ptr = malloc(memory))) {
			printf("Succeeded in allocating %lu MB of RAM\n", (i+1)*sizeof(int));
			blocks[i] = ptr;
			blocks_allocated++;
		}
		else {
			printf("Failed in allocating %lu MB of RAM\n", (i+1)*sizeof(int));
			break;
		}
	}
	
	/* Now use it */
	for (i = 0; i < blocks_allocated; i++) {
		for (j = 0; j < 1024*1024; j++)
			((int *)blocks[i])[j] = 1;
		printf("Succeeded in writing to %lu MB of RAM\n", (i+1)*sizeof(int));
	}

	/* Do this until killed. */
	while (1) {
		/* Sleep until SIGHUP is received */
		printf("Sleeping until SIGHUP is received\n");
		received_hup = 0;
		signal(SIGHUP, onhup);
		while (!received_hup) {
			sleep(10);
		}
		printf("Continuing.\n");
		gettimeofday(&resume_time, NULL);

		/* Now look at all the data we wrote to memory */
		for (i = 0; i < blocks_allocated; i++) {
			for (j = 0; j < 1024*1024; j++)
				if (((int *)blocks[i])[j] != 1)
					printf("What???\n");
		}
		gettimeofday(&finish_time, NULL);

		printf("Done -- reread took %lu us.\n", (unsigned long)((finish_time.tv_sec - resume_time.tv_sec)*1000*1000 + finish_time.tv_usec - resume_time.tv_usec));
	}

	/* We should never get here */
	return 0;
}

void onhup(int signum) {
	received_hup = 1;
}
