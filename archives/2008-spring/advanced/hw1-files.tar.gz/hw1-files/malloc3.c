/* Small program to allocate lots of memory first, then try
   to use it. */

/* With 32-bit ints, each block is 20 MB in size */
#define BLOCK_SIZE 5
#define BLOCKS 8

#include <stdlib.h>
#include <stdio.h>

int main() {
	size_t memory = BLOCK_SIZE*1024*1024*sizeof(int);
	void * ptr;
	void * blocks[BLOCKS];
	long i, j;
	int blocks_allocated = 0;

	/* Acquire lots of memory first */
	for (i = 0; i < BLOCKS; i++) {
		if ((ptr = malloc(memory))) {
			printf("Succeeded in allocating %lu MB of RAM\n", (i+1)*BLOCK_SIZE*sizeof(int));
			blocks[i] = ptr;
			blocks_allocated++;
		}
		else {
			printf("Failed in allocating %lu MB of RAM\n", (i+1)*BLOCK_SIZE*sizeof(int));
			break;
		}
	}
	
	/* Now use it -- uh oh! */
	for (i = 0; i < blocks_allocated; i++) {
		for (j = 0; j < BLOCK_SIZE*1024*1024; j++)
			((int *)blocks[i])[j] = 1;
		printf("Succeeded in writing to %lu MB of RAM\n", (i+1)*BLOCK_SIZE*sizeof(int));
	}

	return 0;
}
