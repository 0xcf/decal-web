/* chroot2.c -- drops privileges and lists the contents of its root directory
 * (intended to be run inside a user-constructed chroot)
 * This is intended for comparison with chroot1.c, which does the chrooting
 * itself. */

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>

int main() {
	DIR * dp;
	struct dirent * entry;
	
	/* If root, drop privileges by becoming someone else
	 * These (presumably) won't work if we're not privileged, but in that
	 * case we don't particularly care */
	setgid(-1);
	if (setuid(-1) && (getuid() == 0 || geteuid() == 0)) {
		fprintf(stderr, "Refusing to run as root\n");
		return 1;
	}

	/* List the contents of the directory, one entry per line
	 * Unlike ls, no sorting or hiding is done */
	if (!(dp = opendir("/"))) {
		perror("Opening directory failed");
		return 2;
	}
	while ((entry = readdir(dp)))
		printf("%s\n", entry->d_name);
	closedir(dp);

	return 0;
}
