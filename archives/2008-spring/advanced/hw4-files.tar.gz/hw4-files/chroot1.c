/* chroot1.c -- chroots, drops privileges, and lists the contents of its
 * root directory
 * While this is sufficient to defend against the well-known attacks on
 * chroot() jails, I don't guarantee that it's not possible to break out
 * of the jail.  Whether this is possible will depend in part on how the
 * program was called and what's available in the chroot (I'm excluding
 * kernel privilege-escalation bugs here). */

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>

#define CHROOT_DIR "/var/empty"

int main() {
	DIR * dp;
	struct dirent * entry;
	
	/* Change our root directory */
	if (chroot(CHROOT_DIR)) {
		perror("chroot() failed");
		return 1;
	}
	/* Make sure the current working directory is inside the chroot */
	if (chdir("/")) {
		perror("chroot() failed");
		return 1;
	}

	/* If root, drop privileges by becoming someone else
	 * These (presumably) won't work if we're not privileged, but in that
	 * case we don't particularly care */
	setgid(-1);
	if (setuid(-1) && (getuid() == 0 || geteuid() == 0)) {
		fprintf(stderr, "Refusing to run as root\n");
		return 1;
	}

	/* List the contents of the directory, one entry per line
	 * Unlike ls, no sorting or hiding is done */
	if (!(dp = opendir("/"))) {
		perror("Opening directory failed");
		return 2;
	}
	while ((entry = readdir(dp)))
		printf("%s\n", entry->d_name);
	closedir(dp);

	return 0;
}
