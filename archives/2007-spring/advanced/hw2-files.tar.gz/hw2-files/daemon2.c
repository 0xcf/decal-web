/* daemon2.c -- second attempt at creating a daemon */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

int main() {
	pid_t pid;

	printf("Parent: pid %d\n", getpid());

	/* Close stdin, stdout, and stderr */
	if (close(0) || close(1) || close(2)) {
		perror("daemon2: could not close stdio");
		exit(1);
	}

	/* Fork, and check if we are the child */
	if ((pid = fork()) == -1) {
		perror("daemon2: could not fork");
		exit(2);
	}
	if (!pid) {
		/* Child process */
		/* Open stdin, stdout, stderr as /dev/null */
		open("/dev/null", O_RDONLY);
		open("/dev/null", O_WRONLY);
		open("/dev/null", O_WRONLY);

		/* Loop forever */
		pid = getpid();
		while (1) {
			printf("%d: foobar\n", pid);
			sleep(5);
		}
	}

	return 0;
}
