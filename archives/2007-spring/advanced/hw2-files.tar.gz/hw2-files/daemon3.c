/* daemon3.c -- third attempt at creating a daemon */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

int main() {
	int fd;
	pid_t pid;

	printf("Parent: pid %d\n", getpid());

	/* Close stdin, stdout, and stderr */
	if (close(0) || close(1) || close(2)) {
		perror("daemon2: could not close stdio");
		exit(1);
	}

	/* Fork, and check if we are the child */
	if ((pid = fork()) == -1) {
		perror("daemon2: could not fork");
		exit(2);
	}
	if (!pid) {
		/* Child process */
		/* Become session leader, changing PGID and detaching
		 * from any possible controlling terminal */
		setsid();

		/* Open stdin, stdout, stderr as /dev/null */
		open("/dev/null", O_RDONLY);
		open("/dev/null", O_WRONLY);
		open("/dev/null", O_WRONLY);

		/* Make absolutely sure we have no controlling tty
		 * setsid() should have done this for us, but it doesn't
		 * hurt to be cautious */
                if ((fd = open("/dev/tty", O_RDWR|O_NOCTTY))) {
                        if (ioctl(fd, TIOCNOTTY) == -1)
                                exit(1);
                        if (close(fd))
                                exit(1);
                }

		/* Go to the root directory */
		chdir("/");
		/* Change the umask to something sane */
		umask(S_IWGRP | S_IWOTH);

		/* Loop forever */
		pid = getpid();
		while (1) {
			printf("%d: foobar\n", pid);
			sleep(5);
		}
	}

	return 0;
}
