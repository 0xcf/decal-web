/* daemon1.c -- first attempt at creating a daemon */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main() {
	pid_t pid;

	printf("Parent: pid %d\n", getpid());

	/* Fork, and check if we are the child */
	if ((pid = fork()) == -1) {
		perror("daemon1: could not fork");
		exit(1);
	}
	if (!pid) {
		/* Child process: loop forever */
		pid = getpid();
		while (1) {
			printf("%d: foobar\n", pid);
			sleep(5);
		}
	}

	return 0;
}
