/* Small program to allocate and actually use lots of memory.
 * Once done using memory, it runs until interrupted by a signal,
 * in order to hog the memory it's written to. */

/* With 32-bit ints, each block is 40 MB in size */
#define BLOCKS 50

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main() {
	size_t memory = 10*1024*1024*sizeof(int);
	void * ptr;
	long i, j;

	for (i = 1; i <= BLOCKS; i++) {
		if (ptr = malloc(memory)) {
			printf("Succeeded in allocating %ld MB of RAM\n", i*10*sizeof(int));
			for (j = 0; j < 10*1024*1024; j++)
				((int *)ptr)[j] = 1;
		}
		else {
			printf("Failed in allocating %ld MB of RAM\n", i*10*sizeof(int));
			break;
		}
	}
	
	while (1)
		sleep(10);
	
	return 0;
}
