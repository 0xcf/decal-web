/* Forks up to TIMES_TO_FORK number of children
 * Each child performs factorial on its PID, then sleeps
 * On signal, or at end, prints out total number of children created */

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>

#define TIMES_TO_FORK 16384

unsigned long long count = 0;
pid_t ppid = 0;
pid_t pid = 0;
unsigned short ischild = 0;

void cleanup(int signal);
long double factorial(unsigned int arg);

int main() {
	struct sigaction * on_signal;

	/* Save our PID */
	ppid = getpid();

	/* Install our signal handler */
	if (!(on_signal = malloc(sizeof(struct sigaction))))
		return 1;
	on_signal->sa_handler = cleanup;
	if (sigaction(SIGINT, on_signal, NULL) == -1)
		return 1;
	if (sigaction(SIGTERM, on_signal, NULL) == -1)
		return 1;
	if (sigaction(SIGQUIT, on_signal, NULL) == -1)
		return 1;

	/* Print out our priority -- this reduces confusion
	 * in the examples where two processes are running in parallel */
	printf("%d: priority %d\n", ppid, getpriority(PRIO_PROCESS, ppid));

	/* Fork up to TIMES_TO_FORK child processes */
	for (count = 1; count <= TIMES_TO_FORK; ++count) {
		pid = fork();
		/* Child process: compute factorial of our PID, then sleep */
		if (!pid) {
			factorial(getpid());
			while (1)
				sleep(1);
		}
	}

	/* End up by calling signal handler as if invoked by SIGTERM */
	cleanup(SIGTERM);
} 

/* Signal handler -- prints out count of children and closes program */
void cleanup(int signal) {
	if (pid) {
		printf("%d: forked %lld processes total\n", ppid, count);
	}
	exit(0);
}

/* Calculates factorial of the argument
 * Works in floating point to work the CPU harder */
long double factorial(unsigned int arg) {
	long double result;

	for (result = 1; arg > 0; arg--)
		result *= arg;

	return result;
}
