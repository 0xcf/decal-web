/* formatstring.c -- classic example of a format string vuln */
#include <stdio.h>

#define BUFSIZE 256

int main(int argc, char ** argv) {
	char buf[BUFSIZE];

	while (fgets(buf, BUFSIZE, stdin))
		/* This should be printf("%s", buf)
		 * Prevents the attacker from using format strings
		 * in input */
		printf(buf);

	return 0;
}
