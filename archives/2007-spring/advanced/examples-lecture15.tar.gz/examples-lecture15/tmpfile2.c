/* tmpfile2.c -- attempt at fixing tmpfile.c which doesn't work */

#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#define TMPFILE "/tmp/foo"
#define BUFSIZE 256

int main() {
	pid_t pid;
	char * filename;
	size_t len = strlen(TMPFILE) + 1;
	FILE * fp;
	char buf[256];

	/* Get our PID and construct a filename TMPFILE.pid */
	pid = getpid();
	if (!(filename = (char *) malloc(len + 6)))
		return 1;
	snprintf(filename, len + 6, "%s.%u", TMPFILE, pid);
	
	/* Open TMPFILE.pid
	 * Two problems: (1) the PID could be obtained by the attacker
	 * between the time the process is started and the time this call
	 * happens; (2) the PID could be quite easily guessed */
	if (!(fp = fopen(filename, "w")))
		return 1;

	while (fgets(buf, BUFSIZE, stdin))
		if (fputs(buf, fp) == EOF) {
			fprintf(stderr, "write failed\n");
			return 1;
		}

	fclose(fp);

	return 0;
}
