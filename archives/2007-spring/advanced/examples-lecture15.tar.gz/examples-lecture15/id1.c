/* id1.c -- shows real and effective user and group IDs, using only
 * interfaces standardized in SUSv3 */

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
	uid_t ruid = getuid(), euid = geteuid();
	gid_t rgid = getgid(), egid = getegid();

	printf("Real user ID:\t\t%u\n", ruid);
	printf("Real group ID:\t\t%u\n", rgid);
	printf("Effective user ID:\t%u\n", euid);
	printf("Effective group ID:\t%u\n", egid);

	return 0;
}
