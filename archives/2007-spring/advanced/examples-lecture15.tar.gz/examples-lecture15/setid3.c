/* setid3.c -- changes IDs using the setuid/setgid calls
 * Version of setid2 that behaves more as you'd expect when both setuid
 * and setgid root -- can you spot the difference? */

#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>

#ifndef _POSIX_SAVED_IDS
#warning _POSIX_SAVED_IDS required for program to function correctly
#endif

void printids(void);

int main() {
	uid_t ruid = getuid(), euid = geteuid();
	gid_t rgid = getgid(), egid = getegid();

	printids();

	/* Call setuid()/setgid() to change IDs 
	 * For root, this will change all IDs; for regular users
	 * on Linux it only changes effective IDs */
	printf("\nSetting effective IDs to real IDs:\n");
	if (setgid(rgid))
		fprintf(stderr, "setgid() failed\n");
	if (setuid(ruid))
		fprintf(stderr, "setuid() failed\n");
	printids();

	/* Try to restore our original IDs */
	printf("\nRestoring original effective IDs:\n");
	if (seteuid(euid))
		fprintf(stderr, "Restoring euid failed\n");
	if (setegid(egid))
		fprintf(stderr, "Restoring egid failed\n");
	printids();

	return 0;
}

void printids() {
	uid_t ruid, euid, suid;
	gid_t rgid, egid, sgid;

	getresuid(&ruid, &euid, &suid);
	getresgid(&rgid, &egid, &sgid);

	printf("Real user ID:\t\t%u\n", ruid);
	printf("Real group ID:\t\t%u\n", rgid);
	printf("Effective user ID:\t%u\n", euid);
	printf("Effective group ID:\t%u\n", egid);
	printf("Saved set-user-ID:\t%u\n", suid);
	printf("Saved set-group-ID:\t%u\n", sgid);

	return;
}
