/* tmpfile.c -- code which creates temporary files insecurely */
#include <stdio.h>

#define TMPFILE "/tmp/foo"
#define BUFSIZE 256

int main() {
	FILE * fp;
	char buf[256];

	/* If TMPFILE exists already, it will be truncated
	 * If TMPFILE is a symlink, the target will be truncated */
	if (!(fp = fopen(TMPFILE, "w")))
		return 1;

	while (fgets(buf, BUFSIZE, stdin))
		if (fputs(buf, fp) == EOF) {
			fprintf(stderr, "write failed\n");
			return 1;
		}

	fclose(fp);

	return 0;
}
