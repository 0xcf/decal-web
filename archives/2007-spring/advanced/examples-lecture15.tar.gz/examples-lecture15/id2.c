/* id2.c -- on Linux, shows real, effective, and saved set-user-IDs using
 * the non-standard (as of 2007) getresuid/getresgid interfaces*/

#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>

int main() {
	uid_t ruid, euid, suid;
	gid_t rgid, egid, sgid;

	getresuid(&ruid, &euid, &suid);
	getresgid(&rgid, &egid, &sgid);

	printf("Real user ID:\t\t%u\n", ruid);
	printf("Real group ID:\t\t%u\n", rgid);
	printf("Effective user ID:\t%u\n", euid);
	printf("Effective group ID:\t%u\n", egid);
	printf("Saved set-user-ID:\t%u\n", suid);
	printf("Saved set-group-ID:\t%u\n", sgid);

	return 0;
}
