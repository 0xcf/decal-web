/* setid1.c -- demonstrates changing the effective user/group ID and the use of
 * the saved set-user/group IDs
 * Uses non-standard getresuid/getresgid interface */

#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>

#ifndef _POSIX_SAVED_IDS
#warning _POSIX_SAVED_IDS required for program to function correctly
#endif

void printids(void);

int main() {
	uid_t ruid = getuid(), euid = geteuid();
	gid_t rgid = getgid(), egid = getegid();

	/* Print out our initial user and group IDs */
	printids();

	/* Change our effective IDs to match our real IDs */
	printf("\nSetting effective IDs to real IDs:\n");
	if (setegid(rgid))
		fprintf(stderr, "Setting egid = rgid failed\n");
	if (seteuid(ruid))
		fprintf(stderr, "Setting euid = ruid failed\n");
	printids();

	/* Restore our original IDs
	 * We can do this because the saved set-IDs are the original ones */
	printf("\nRestoring original effective IDs:\n");
	if (seteuid(euid))
		fprintf(stderr, "Restoring euid failed -- is _POSIX_SAVED_IDs available?\n");
	if (setegid(egid))
		fprintf(stderr, "Restoring egid failed -- is _POSIX_SAVED_IDs available?\n");
	printids();

	return 0;
}

void printids() {
	uid_t ruid, euid, suid;
	gid_t rgid, egid, sgid;

	getresuid(&ruid, &euid, &suid);
	getresgid(&rgid, &egid, &sgid);

	printf("Real user ID:\t\t%u\n", ruid);
	printf("Real group ID:\t\t%u\n", rgid);
	printf("Effective user ID:\t%u\n", euid);
	printf("Effective group ID:\t%u\n", egid);
	printf("Saved set-user-ID:\t%u\n", suid);
	printf("Saved set-group-ID:\t%u\n", sgid);

	return;
}
