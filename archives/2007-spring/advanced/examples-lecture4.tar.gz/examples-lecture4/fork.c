/* Forks 100 processes.  Children exit immediately.
 * Sleeps a second before calling fork() again. */
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#define TIMES_TO_FORK 100

int main() {
	int i;
	pid_t pid;

	for (i = 0; i < TIMES_TO_FORK; ++i) {
		pid = fork();
		if (!pid)
			exit(0);
		printf("Forked %d processes\n", i);
		sleep(1);
	}

	return 0;
} 
