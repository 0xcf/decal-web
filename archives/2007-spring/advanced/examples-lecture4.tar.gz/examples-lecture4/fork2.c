/* Forks TIMES_TO_FORK number of children one at a time
 * Performs waitpid() on each to avoid zombies
 * Sleep between each execution of fork() to avoid a forkbomb */

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

#define TIMES_TO_FORK 100

int main() {
	int i;
	pid_t pid;

	for (i = 1; i <= TIMES_TO_FORK; ++i) {
		pid = fork();
		if (!pid) {
			exit(0);
		} else {
			waitpid(pid, NULL, 0);
		}
		printf("Forked %d processes\n", i);
		sleep(1);
	}

	return 0;
} 
