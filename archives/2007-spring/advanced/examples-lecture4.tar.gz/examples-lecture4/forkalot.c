/* Fork 100,000 times, one at a time.  Each child exits immediately.
 * Zombies are not waited for. */
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

#define TIMES_TO_FORK 100000

int main() {
	int i;
	pid_t pid;

	for (i = 0; i < TIMES_TO_FORK; ++i) {
		pid = fork();
		if (!pid)
			exit(0);
	}

	return 0;
} 
