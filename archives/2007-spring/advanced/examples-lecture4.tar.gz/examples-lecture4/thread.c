/* Create 100,000 threads, each of which exits immediately. */
#include <pthread.h>

#define TIMES_TO_FORK 100000

void * thread_main(void * ptr);

int main() {
	int i;
	pthread_t thread;

	for (i = 0; i < TIMES_TO_FORK; ++i) {
		pthread_create(&thread, NULL, thread_main, NULL);
	}

	return 0;
} 

void * thread_main(void * ptr) {
	return 0;
}
