/* Small program to allocate and actually use lots of memory. */

/* With 32-bit ints, each block is 400 MB in size */
#define BLOCKS 8

#include <stdlib.h>
#include <stdio.h>

int main() {
	size_t memory = 100*1024*1024*sizeof(int);
	void * ptr;
	long i, j;

	for (i = 1; i <= BLOCKS; i++) {
		if (ptr = malloc(memory)) {
			printf("Succeeded in allocating %ld MB of RAM\n", i*100*sizeof(int));
			for (j = 0; j < 100*1024*1024; j++)
				((int *)ptr)[j] = 1;
		}
		else {
			printf("Failed in allocating %ld MB of RAM\n", i*100*sizeof(int));
			break;
		}
	}
	
	return 0;
}
