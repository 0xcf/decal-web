/* Small program that tries to allocate lots of memory
   (by default, 3 GB, more than on this system. */

/* Each block is 100 MB in size */
#define BLOCKS 32

#include <stdlib.h>
#include <stdio.h>

int main() {
	size_t memory = 100*1024*1024;
	void * ptr;
	long i;

	for (i = 1; i <= BLOCKS; i++) {
		if (ptr = malloc(memory))
			printf("Succeeded in allocating %ld MB of RAM\n", i*100);
		else {
			printf("Failed in allocating %ld MB of RAM\n", i*100);
			break;
		}
	}
	
	return 0;
}
