/* intoverflow.c -- code vulnerable to an integer overflow */

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {
	uint8_t length;
	char buf[512];
	char * newbuf = NULL;

	/* Grab up to 512 bytes from standard input */
	fgets(buf, 512, stdin);

	/* If strlen > max(uint8_t), length will wrap around */
	length = strlen(buf);
	printf("%u\n", length);

	/* Allocate a new buffer -- based on the length we got above */
	if (!(newbuf = (char *)malloc(length*sizeof(char))))
		return 1;

	/* Blindly copy contents of buf into newbuf -- uh oh! */
	strcpy(newbuf, buf);

	printf("%s\n", newbuf);

	return 0;
}
