/* Forks up to TIMES_TO_FORK number of children
 * Performs a read from a (hopefully) large file per child created
 * Each child performs factorial on its PID, then sleeps
 * On signal, or at end, prints out total number of children created
 * Intended to illustrate the effects of blocking I/O on the run queue */

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define TIMES_TO_FORK 16384
#define READ_SIZE 1048576
#define FILE_TO_READ "./big-file-of-zeros"

unsigned long long count = 0;
pid_t ppid = 0;
pid_t pid = 0;
unsigned short ischild = 0;

void cleanup(int signal);
long double factorial(unsigned int arg);

int main(int argc, char * argv[]) {
	struct sigaction * on_signal;
	int fd;
	unsigned char buf[READ_SIZE];

	/* Give the user a friendly reminder if he forgot to supply a
	 * file to read from */
	if (argc < 2) {
		printf("Usage: %s file-to-read\n", argv[0]);
		return 0;
	}

	/* Save our PID */
	ppid = getpid();

	/* Install our signal handler */
	if (!(on_signal = malloc(sizeof(struct sigaction))))
		return 1;
	on_signal->sa_handler = cleanup;
	if (sigaction(SIGINT, on_signal, NULL) == -1)
		return 1;
	if (sigaction(SIGTERM, on_signal, NULL) == -1)
		return 1;
	if (sigaction(SIGQUIT, on_signal, NULL) == -1)
		return 1;

	/* Open the file to be read from */
	if ((fd = open(argv[1], O_RDONLY)) == -1) {
		perror(argv[0]);
		return 1;
	}

	/* Print out our priority -- this reduces confusion
	 * in the examples where two processes are running in parallel */
	printf("%d: forkloop-io priority %d\n", ppid, getpriority(PRIO_PROCESS, ppid));

	/* Fork up to TIMES_TO_FORK child processes
	 * Read from our file after each fork() */
	for (count = 1; count <= TIMES_TO_FORK; ++count) {
		pid = fork();
		if (!pid) {
			factorial(getpid());
			while (1)
				sleep(1);
		}
		read(fd, buf, READ_SIZE);
	}

	/* End up by calling signal handler as if invoked by SIGTERM */
	cleanup(SIGTERM);
} 

/* Signal handler -- prints out count of children and closes program */
void cleanup(int signal) {
	if (pid) {
		printf("%d: forked %lld processes total\n", ppid, count);
	}
	exit(0);
}

/* Calculates factorial of the argument */
long double factorial(unsigned int arg) {
	long double result;

	for (result = 1; arg > 0; arg--)
		result *= arg;

	return result;
}
