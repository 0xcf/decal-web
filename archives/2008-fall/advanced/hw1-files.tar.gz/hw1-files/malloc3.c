/* Small program to allocate and actually use lots of memory. */

/* Blocks of memory to allocate */
#define BLOCKS 8
/* Size of each block in MB */
#define BLOCK_SIZE 8

#include <stdlib.h>
#include <stdio.h>

int main() {
	size_t memory = BLOCK_SIZE*1024*1024;
	void * ptr[BLOCKS];
	long i, j;

	/* Allocate the memory one block at a time*/
	for (i = 0; i < BLOCKS; i++) {
		if (ptr[i] = malloc(memory)) {
			printf("Succeeded in allocating %ld MB of RAM\n", (i+1)*BLOCK_SIZE);
		}
		else {
			printf("Failed in allocating %ld MB of RAM\n", (i+1)*BLOCK_SIZE);
			return 1;
		}
	}

	/* Now try to write to the allocated memory, one block at a time */
	for (i = 0; i < BLOCKS; i++) {
		for (j = 0; j < memory/sizeof(int); j++) {
			((int *)ptr[i])[j] = 1;
		}
		printf("Succeeded in writing to %ld MB of RAM\n", (i+1)*BLOCK_SIZE);
	}

	return 0;
}
