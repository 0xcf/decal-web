/* tmpfile7.c -- atomic NFS-safe creation of a file with a predictable name */

#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

#define TMPFILE "/tmp/tmpfile7"
#define BUFSIZE 256

int main() {
	pid_t pid;
	char * filename;
	char * temp_filename;
	size_t len = strlen(TMPFILE) + 1;
	int fd;
	struct stat filestat;
	FILE * fp;
	char buf[256];

	/* Get our PID and construct a filename TMPFILE.pid */
	pid = getpid();
        if (!(filename = (char *) malloc(len + 6)))
                return 1;
        snprintf(filename, len + 6, "%s.%u", TMPFILE, pid);

	/* Construct a random filename by adding random characters to TMPFILE */
	if (!(temp_filename = (char *) malloc(len + 7)))
		return 1;
	snprintf(temp_filename, len + 7, "%s.%s", TMPFILE, "XXXXXX");
	if (!(temp_filename = mktemp(temp_filename)))
		return 1;
	
	/* Create the temporary file, permissions 0600 */
	if ((fd = open(temp_filename, O_WRONLY|O_CREAT|O_EXCL, 0600)) == -1) {
		perror("File creation failed");
		return 1;
	}

	/* Create a hard link from our random filename to the desired one
	 * The stat logic is for NFS: it's possible that link creation
	 * succeeds, but that the NFS server crashes before it can return
	 * success to us; hence we check the link count to see if it's
	 * increased */
	if (link(temp_filename, filename) == -1) {
		if (fstat(fd, &filestat) == -1) {
			unlink(temp_filename);
			return 1;
		}
		if (filestat.st_nlink != 2) {
			fprintf(stderr, "Link creation failed\n");
			unlink(temp_filename);
			return 1;
		}
	}
	/* Remove the random name, leaving us with just the desired one
	 * Remember this doesn't affect the open file descriptor */
	unlink(temp_filename);

	/* Associate a stdio FILE pointer with the file descriptor, so that
	 * we can use higher-level buffered I/O functions like fputs with
	 * this file */
	if (!(fp = fdopen(fd, "w")))
		return 1;

	/* Read data from the user 256 bytes at a time and write it to the
	 * temporary file */
	while (fgets(buf, BUFSIZE, stdin))
		if (fputs(buf, fp) == EOF) {
			fprintf(stderr, "write failed\n");
			return 1;
		}

	/* Close the temporary file */
	fclose(fp);

	return 0;
}
