/* tmpfile5.c -- temporary file creation */

#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

#define TMPFILE "/tmp/tmpfile5.XXXXXX"
#define BUFSIZE 256

int main() {
	char * filename;
	size_t len = strlen(TMPFILE) + 1;
	mode_t old_umask;
	int fd;
	FILE * fp;
	char buf[256];

	/* Construct a random filename by replacing the XXXXXX in TMPFILE
	 * with random characters, and then open it */
	if (!(filename = (char *) malloc(len)))
		return 1;
	strncpy(filename, TMPFILE, len);
	/* Change the umask -- POSIX does not guarantee us that our temporary
	 * file created with mkstemp() won't be world-writable otherwise */
	old_umask = umask(077);
	if ((fd = mkstemp(filename)) == -1) {
		perror("File creation failed");
		return 1;
	}
	umask(old_umask);
	
	/* Associate a stdio FILE pointer with the file descriptor, so that
	 * we can use higher-level buffered I/O functions like fputs with
	 * this file */
	if (!(fp = fdopen(fd, "w")))
		return 1;

	/* Read data from the user 256 bytes at a time and write it to the
	 * temporary file */
	while (fgets(buf, BUFSIZE, stdin))
		if (fputs(buf, fp) == EOF) {
			fprintf(stderr, "write failed\n");
			return 1;
		}

	/* Close the temporary file */
	fclose(fp);

	return 0;
}
