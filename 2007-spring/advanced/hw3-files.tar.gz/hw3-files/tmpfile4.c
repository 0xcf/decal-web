/* tmpfile4.c -- temporary file creation */

#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

#define TMPFILE "/tmp/tmpfile4.XXXXXX"
#define BUFSIZE 256

int main() {
	char * filename;
	size_t len = strlen(TMPFILE) + 1;
	int fd;
	FILE * fp;
	char buf[256];

	/* Construct a random filename by replacing the XXXXXX in TMPFILE
	 * with random characters */
	if (!(filename = (char *) malloc(len)))
		return 1;
	strncpy(filename, TMPFILE, len);
	if (!(filename = mktemp(filename)))
		return 1;
	
	/* Create the temporary file, permissions 0600 */
	if ((fd = open(filename, O_WRONLY|O_CREAT|O_EXCL, 0600)) == -1) {
		perror("File creation failed");
		return 1;
	}

	/* Associate a stdio FILE pointer with the file descriptor, so that
	 * we can use higher-level buffered I/O functions like fputs with
	 * this file */
	if (!(fp = fdopen(fd, "w")))
		return 1;

	/* Read data from the user 256 bytes at a time and write it to the
	 * temporary file */
	while (fgets(buf, BUFSIZE, stdin))
		if (fputs(buf, fp) == EOF) {
			fprintf(stderr, "write failed\n");
			return 1;
		}

	/* Close the temporary file */
	fclose(fp);

	return 0;
}
