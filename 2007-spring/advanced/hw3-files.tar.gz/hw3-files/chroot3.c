/* chroot3.c -- drops privileges and shows some info about the system */

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/utsname.h>
#include <sys/wait.h>

#define DATE_PROG "/bin/date"

int main() {
	char hostname[HOST_NAME_MAX+1];
	struct hostent * hostinfo;
	char * cname;
	struct utsname unameinfo;
	pid_t pid;

	/* If root, drop privileges by becoming someone else
	 * These (presumably) won't work if we're not privileged, but in that
	 * case we don't particularly care */
	setgid(-1);
	if (setuid(-1) && (getuid() == 0 || geteuid() == 0)) {
		fprintf(stderr, "Refusing to run as root\n");
		return 1;
	}

	/* Get our hostname */
	if (gethostname(hostname, HOST_NAME_MAX+1)) {
		perror("Couldn't get my hostname");
		return 2;
	}
	/* Get the canonical form of our hostname */
	if ((hostinfo = gethostbyname(hostname)))
		cname = hostinfo->h_name;
	else
		cname = hostname;
	/* Get uname information */
	if (uname(&unameinfo)) {
		perror("Couldn't get uname info");
		return 2;
	}
	/* Print out a header */
	printf("%s\n", cname);
	printf("(%s %s %s)\n", unameinfo.sysname, unameinfo.release, unameinfo.machine);

	/* Run date */
	if ((pid = fork()) == -1) {
		perror("Couldn't fork()");
		return 2;
	}
	if (pid)
		/* Parent process -- wait for child to finish */
		waitid(P_PID, pid, NULL, WEXITED);
	else
		/* Child process -- exec date binary */
		execl(DATE_PROG, DATE_PROG, NULL);

	return 0;
}
