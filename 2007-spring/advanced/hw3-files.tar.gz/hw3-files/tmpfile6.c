/* tmpfile6.c -- atomic creation of a predictable file name */

#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

#define TMPFILE "/tmp/tmpfile6"
#define BUFSIZE 256

int main() {
	pid_t pid;
	char * filename;
	size_t len = sizeof(TMPFILE) + 1;
	int fd;
	FILE * fp;
	char buf[256];

        /* Get our PID and construct a filename TMPFILE.pid */
        pid = getpid();
        if (!(filename = (char *) malloc(len + 6)))
                return 1;
        snprintf(filename, len + 6, "%s.%u", TMPFILE, pid);

	/* Create the temporary file, permissions 0600 */
	if ((fd = open(filename, O_WRONLY|O_CREAT|O_EXCL, 0600)) == -1) {
		perror("File creation failed");
		return 1;
	}

	/* Associate a stdio FILE pointer with the file descriptor, so that
	 * we can use higher-level buffered I/O functions like fputs with
	 * this file */
	if (!(fp = fdopen(fd, "w")))
		return 1;

	/* Read data from the user 256 bytes at a time and write it to the
	 * temporary file */
	while (fgets(buf, BUFSIZE, stdin))
		if (fputs(buf, fp) == EOF) {
			fprintf(stderr, "write failed\n");
			return 1;
		}

	/* Close the temporary file */
	fclose(fp);

	return 0;
}
